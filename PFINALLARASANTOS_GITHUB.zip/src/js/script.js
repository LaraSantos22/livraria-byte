document.addEventListener("DOMContentLoaded", () => {
    const btnTema = document.getElementById("btn-tema");
    if (btnTema) {
        btnTema.addEventListener("click", () => {
            document.body.classList.toggle("dark-mode");
        });
    }

    const inputBusca = document.getElementById("busca-livro");
    if (inputBusca) {
        inputBusca.addEventListener("input", (e) => {
            const termo = e.target.value.toLowerCase().trim();
            const cards = document.querySelectorAll(".livro-card");
            cards.forEach(card => {
                const titulo = card.getAttribute("data-titulo");
                if (titulo.includes(termo)) {
                    card.style.display = "block";
                } else {
                    card.style.display = "none";
                }
            });
        });
    }
});

// ---- Páginas extras: detalhes do livro e confirmação do contato ----
const LIVROS = {
    1: { titulo: "Desenvolvimento Web", categoria: "HTML, CSS e JS", preco: "R$ 89,90", capa: "livro-1.jpg" },
    2: { titulo: "Design de Interface", categoria: "UX e UI na prática", preco: "R$ 110,00", capa: "livro-2.jpg" },
    3: { titulo: "Lógica de Programação", categoria: "Do zero ao algoritmo", preco: "R$ 65,00", capa: "livro-3.jpg" },
    4: { titulo: "PHP e MySQL", categoria: "Sites dinâmicos", preco: "R$ 125,50", capa: "livro-4.jpg" }
};

document.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);

    const detalhe = document.getElementById("detalhe-livro");
    if (detalhe) {
        const livro = LIVROS[params.get("id")];
        if (livro) {
            detalhe.innerHTML = `
                <img src="../img/${livro.capa}" alt="Capa do livro ${livro.titulo}" style="max-width:220px">
                <h2>${livro.titulo}</h2>
                <p class="categoria">${livro.categoria}</p>
                <span class="preco">${livro.preco}</span>
                <p><button id="btn-comprar" class="btn-primary">Adicionar ao carrinho</button></p>
                <p><a href="produtos.html">← Voltar ao catálogo</a></p>`;
            document.getElementById("btn-comprar").addEventListener("click", () => {
                salvarCarrinho(lerCarrinho() + 1);
            });
        } else {
            detalhe.innerHTML = "<h2>Livro não encontrado</h2><a href='produtos.html'>Voltar ao catálogo</a>";
        }
    }

    const resumo = document.getElementById("resumo-confirmacao");
    if (resumo) {
        const esc = t => (t || "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
        resumo.innerHTML = `Obrigada, <strong>${esc(params.get("nome"))}</strong>! Recebemos sua mensagem
            (retorno para <strong>${esc(params.get("email"))}</strong>):<br><em>${esc(params.get("mensagem"))}</em>`;
    }
});


// ---- Carrinho persistente (mantém a contagem ao navegar entre as páginas) ----
function lerCarrinho() {
    try { return Number(localStorage.getItem("carrinho-byte")) || 0; }
    catch (e) { return 0; }
}

function salvarCarrinho(qtd) {
    try { localStorage.setItem("carrinho-byte", qtd); } catch (e) {}
    atualizarContador();
}

function atualizarContador() {
    const contador = document.getElementById("contador-carrinho");
    if (contador) contador.textContent = lerCarrinho();
}

document.addEventListener("DOMContentLoaded", atualizarContador);
